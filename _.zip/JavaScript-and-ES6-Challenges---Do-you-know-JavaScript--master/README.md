## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/javascript-and-es6-challenges-do-you-know-javascript-video/9781789955606)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# JavaScript-and-ES6-Challenges---Do-you-know-JavaScript-
JavaScript and ES6 Challenges - Do you know JavaScript?, published by Packt
